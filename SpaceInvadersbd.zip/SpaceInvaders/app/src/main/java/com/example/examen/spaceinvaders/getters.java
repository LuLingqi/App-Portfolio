package com.example.examen.spaceinvaders;

public class getters {

    int score;

    public getters(int score) {
        this.score = score;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
