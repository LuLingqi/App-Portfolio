package com.example.examen.spaceinvaders;

import android.graphics.RectF;

public class DefenceBrick {

    private RectF rect;

    public boolean isVisible;

    public DefenceBrick(int row,int column,int shelterNumber,int screenX,int screenY){

        int width = screenX/110;
        int height = screenY/60;

        isVisible = true;

        //A veces una bala atraviesa este relleno
        //Establece el relleno a 0 si te causa molestia
        int brickPadding = 0;

        //El numero de guaridas
        int shelterPadding = screenX/9;
        int startHeight = screenY -(screenY/10 *2);

        rect = new RectF(column * width + brickPadding +
                (shelterPadding * shelterNumber) +
                shelterPadding + shelterPadding * shelterNumber,
                row * height + brickPadding + startHeight,
                column * width + width - brickPadding + (shelterPadding * shelterNumber) +
                        shelterPadding + shelterPadding * shelterNumber,
                row * height + height - brickPadding + startHeight);


    }

    public RectF getRect(){
        return this.rect;
    }

    public void setInvisible(){
        isVisible = false;
    }

    public boolean getVisibility(){
        return isVisible;
    }

}
