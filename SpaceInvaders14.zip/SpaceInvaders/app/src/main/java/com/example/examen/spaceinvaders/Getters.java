package com.example.examen.spaceinvaders;

public class Getters {

    int score;

    public Getters(int score) {
        this.score = score;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
