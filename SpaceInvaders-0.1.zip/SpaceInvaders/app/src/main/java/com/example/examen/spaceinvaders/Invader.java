package com.example.examen.spaceinvaders;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

import java.util.Random;
import java.util.logging.Level;

public class Invader {

    RectF rect;

    Random generator = new Random();

    //La nave espacial del jugador va a ser representada por un Bitmap
    private Bitmap bitmap1;
    private Bitmap bitmap2;

    //Que tan largo y ancho se nuestro Invader
    private float length;
    private float height;

    //X es el extremo a la izquierda del rectangulo que le da forma a nuestro invader
    private float x;

    //Y es la coordenada superior
    private float y;

    //Esto tendra l arapidez de los pixeles por segundo a la que invader se movera
    private float shipSpeed;

    public final int LEFT = 1;
    public final int RIGHT = 2;

    //Se esta moviendo la nave espacial y en que direccion
    private int shipMoving = RIGHT;

    boolean isVisible;

    public Invader(Context context,int row,int column,int screenX,int screenY){

        //Inicializa un RectF vacio
        rect = new RectF();

        length = screenX/25;
        height = screenY/25;

        isVisible = true;

        int padding = screenX/25;

        x = column*(length + padding);
        y = row*(length + padding/4);

        //Inicializa el bitmap
        bitmap1 = BitmapFactory.decodeResource(context.getResources(),R.drawable.enemygreen1);
        bitmap2 = BitmapFactory.decodeResource(context.getResources(),R.drawable.enemygreen2);

        //Ajueta el primer bitmap a un tamaño apropiado para la resolucion de la pantalla
        bitmap1 = Bitmap.createScaledBitmap(bitmap1,(int)(length),(int)(height),false);

        //Ajueta el segundo bitmap a un tamaño apropiado para la resolucion de la pantalla
        bitmap2 = Bitmap.createScaledBitmap(bitmap1,(int)(length),(int)(height),false);

        //Que tan rapido va el invader en pixeles por segundo
        shipSpeed = 100;

    }

    public void setInvisible(){

        isVisible = false;
    }

    public boolean getVisibility(){
        return isVisible;
    }

    public RectF getRect(){
        return rect;
    }

    public Bitmap getBitmap(){
        return bitmap1;
    }

    public Bitmap getBitmap2(){
        return bitmap2;
    }

    public float getX(){
        return x;
    }

    public float getY(){
        return y;
    }

    public float getLength(){
        return length;
    }

    public void update(long fps){

        if(shipMoving == LEFT){
            x = x +shipSpeed/fps;
        }

        if(shipMoving ==RIGHT){
            x = x - shipSpeed/fps;
        }

        //Actualiza el rect el cual usado para detectar impactos
        rect.top = y;
        rect.bottom = y + height;
        rect.left = x;
        rect.right = x +length;
    }

    public void dropDownAndReverse(){

        if(shipMoving == LEFT){
            shipMoving = RIGHT;
        }else{
            shipMoving = LEFT;
        }
        y = y + 10;

        shipSpeed = shipSpeed * 1f;
    }

    public boolean takeAim(float playerShipX,float playerShipLength){

        int randomNumer = -1;

        //Si esta cerca del jugador
        if((playerShipX + playerShipLength > x && playerShipX +
                playerShipLength< x + length)|| (playerShipX > x &&
                playerShipX < x +length)){

            //Una probabilidad de 1 en 500 chance para disparar
            randomNumer = generator.nextInt(500);
            if(randomNumer == 0){
                return true;
            }

            //Si esta disparando aleatoriamente(sin estar el jugador cerca) una probalidad de 1 en 5000
            randomNumer = generator.nextInt(5000);
            if(randomNumer == 0){
                return  true;
            }
        }
        return false;
    }
}
