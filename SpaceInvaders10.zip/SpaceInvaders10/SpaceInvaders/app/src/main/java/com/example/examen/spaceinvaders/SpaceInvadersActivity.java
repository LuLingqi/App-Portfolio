package com.example.examen.spaceinvaders;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Point;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

// SpaceInvadersActivity es el punto de entrada al juego.
// Se va a encargar del ciclo de vida del juego al llamar
// los métodos de spaceInvadersView cuando sean solicitados por el OS.

public class SpaceInvadersActivity extends Activity implements View.OnClickListener {

    private SoundPool soundPool;

    // spaceInvadersView será la visualización del juego
    // También tendrá la lógica del juego
    // y responderá a los toques a la pantalla

    SpaceInvadersView spaceInvadersView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.LOLLIPOP){
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            soundPool = new SoundPool.Builder()
                    .setMaxStreams(6)
                    .setAudioAttributes(audioAttributes)
                    .build();
        }else{
            soundPool = new SoundPool(6,AudioManager.STREAM_MUSIC,0);
        }

        // Obtener un objeto de Display para accesar a los detalles de la pantalla
        Display display = getWindowManager().getDefaultDisplay();

        // Cargar la resolución a un objeto de Point
        Point size = new Point();
        display.getSize(size);


        // Inicializar gameView y establecerlo como la visualización
        spaceInvadersView = new SpaceInvadersView(this, size.x, size.y);

        spaceInvadersView.gameLayout = new FrameLayout(this);
        spaceInvadersView.gameWidgets = new LinearLayout (this);

        Button pauseButton = new Button(this);

        pauseButton.setWidth(100);
        pauseButton.setHeight(2);
        pauseButton.setText("Pause");

        spaceInvadersView.gameWidgets.addView(pauseButton);

        spaceInvadersView.gameLayout.addView(spaceInvadersView);
        spaceInvadersView.gameLayout.addView(spaceInvadersView.gameWidgets);

        setContentView(spaceInvadersView.gameLayout);
        pauseButton.setOnClickListener(this);



    }

    // Este método se ejecuta cuando el jugador empieza el juego
    @Override
    protected void onResume() {
        super.onResume();

        // Le dice al método de reanudar del gameView que se ejecute
        spaceInvadersView.resume();
    }

    // Este método se ejecuta cuando el jugador se sale del juego
    @Override
    protected void onPause() {
        super.onPause();

        // Le dice al método de pausa del gameView que se ejecute
        spaceInvadersView.pause();
    }

    public void showScore(){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setTitle("Ranking");
        builder1.setMessage("Write your message here.");
        builder1.setCancelable(true);

        // Initialize a new list of scores
        final ArrayList<String> scores = new ArrayList<String>();
        scores.add("Juan 10");
        scores.add("Paco 20");
        scores.add("Erica 30");
        scores.add("Eustoma 40");
        scores.add("Evening Primrose");


        final ArrayAdapter arrayAdapter = new ArrayAdapter<String>(
                getApplicationContext(), // Context
                android.R.layout.simple_list_item_single_choice, // Layout
                scores // List

        );


     /*
                    AlertDialog.Builder setSingleChoiceItems (ListAdapter adapter,
                                        int checkedItem,
                                        DialogInterface.OnClickListener listener)

                        Set a list of items to be displayed in the dialog as the content, you will
                        be notified of the selected item via the supplied listener. The list will
                        have a check mark displayed to the right of the text for the checked item.
                        Clicking on an item in the list will not dismiss the dialog. Clicking
                        on a button will dismiss the dialog.

                        Parameters
                            adapter ListAdapter: The ListAdapter to supply the list of items
                            checkedItem int: specifies which item is checked. If -1 no items are checked.
                            listener DialogInterface.OnClickListener: notified when an item on
                                        the list is clicked. The dialog will not be dismissed when
                                        an item is clicked. It will only be dismissed if clicked
                                        on a button, if no buttons are supplied it's up to the
                                        user to dismiss the dialog.

                        Returns
                            AlertDialog.Builder This Builder object to allow for chaining
                                                of calls to set methods
                */


        builder1.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                System.out.println("Clickeado");
            }
        });

        AlertDialog alert11 = builder1.create();
        alert11.show();


        // Change the alert dialog background color

        // Finally, display the alert dialog
        //dialog.show();
    }


    @Override
    public void onClick(View v) {
        if(spaceInvadersView.playing == true) {
            spaceInvadersView.pause();
            showScore();
        }else {
            spaceInvadersView.resume();
        }
    }
}
